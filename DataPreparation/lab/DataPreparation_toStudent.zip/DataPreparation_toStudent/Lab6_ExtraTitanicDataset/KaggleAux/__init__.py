import predict

__all__ = ['predict']